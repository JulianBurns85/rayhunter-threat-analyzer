#!/usr/bin/env python3
"""
baseline_comparison.py v2 (v4.4.3) — control capture vs investigation capture.

Same metrics, same extraction, on both sides; rates per capture-hour; exact conditional
binomial test (one-sided, investigation > baseline). Replaces baseline_rrc.py (inventory is
now `--mode inventory`).

  python baseline_comparison.py --mode inventory --input DIR
  python baseline_comparison.py --mode capture   --input CLEAN_DIR [CLEAN_DIR2 ...] --output baseline_profile.json
  python baseline_comparison.py --mode compare   --baseline baseline_profile.json --investigation DIR

Interpretation limits: one control site/time cannot establish a general baseline. Use several
controls (different times/locations, same device). p-values assume Poisson-like counts; real
sessions are overdispersed, so treat them as screening, not proof.
"""
import argparse
import json
import math
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

EMM = {65: "attach_request", 68: "attach_reject", 72: "tau_request", 75: "tau_reject",
       82: "auth_request", 84: "auth_reject", 85: "identity_request", 93: "smc"}
ID_IMSI = 1
COUNT_METRICS = ["identity_request", "identity_request_imsi", "identity_request_imsi_plain",
                 "auth_request", "auth_reject", "smc", "attach_request", "tau_request",
                 "attach_reject", "tau_reject", "rrc_release", "measurement_report",
                 "handover_command"]
BASE_FIELDS = ["frame.time_epoch", "nas_eps.nas_msg_emm_type", "nas_eps.emm.id_type2",
               "nas_eps.security_header_type", "_ws.col.Info"]
OPTIONAL_FIELDS = ["lte-rrc.mobilityControlInfo_element"]   # dropped if this tshark lacks it


# ---------------------------------------------------------------- extraction
def _ints(s: str) -> List[int]:
    out = []
    for tok in (s or "").split(","):
        tok = tok.strip()
        if tok:
            try:
                out.append(int(tok, 0))
            except ValueError:
                pass
    return out


def parse_rows(rows: List[List[str]], has_ho_field: bool = False) -> Dict:
    """rows: split tshark field rows -> per-file metrics (pure; unit-testable)."""
    c = {k: 0 for k in COUNT_METRICS}
    times = []
    for r in rows:
        r = r + [""] * (6 - len(r))
        try:
            times.append(float(r[0]))
        except ValueError:
            continue
        emm, idt, hdr, info = _ints(r[1]), _ints(r[2]), _ints(r[3]), r[4]
        for i, m in enumerate(emm):
            name = EMM.get(m)
            if not name:
                continue
            c[name] = c.get(name, 0) + 1
            if name == "identity_request":
                t = idt[i] if i < len(idt) else (idt[0] if idt else None)
                if t == ID_IMSI:
                    c["identity_request_imsi"] += 1
                    h = hdr[i] if i < len(hdr) else (hdr[0] if hdr else 0)
                    if h == 0:
                        c["identity_request_imsi_plain"] += 1
        if "RRCConnectionRelease" in info:
            c["rrc_release"] += 1
        if "MeasurementReport" in info:
            c["measurement_report"] += 1
        if has_ho_field and r[5].strip():
            c["handover_command"] += 1
    dur = (max(times) - min(times)) if len(times) > 1 else 0.0
    return {"counts": c, "duration_s": round(dur, 3), "frames": len(times)}


def _tshark() -> str:
    exe = shutil.which("tshark")
    if not exe:
        sys.exit("tshark not found on PATH (install Wireshark).")
    return exe


def _available_fields(exe: str) -> set:
    out = subprocess.run([exe, "-G", "fields"], capture_output=True, text=True, timeout=120).stdout
    return {ln.split("\t")[2] for ln in out.splitlines() if ln.startswith("F\t") and len(ln.split("\t")) > 2}


def analyze_file(path: Path, exe: str, avail: set) -> Dict:
    fields = BASE_FIELDS + [f for f in OPTIONAL_FIELDS if f in avail]
    cmd = [exe, "-r", str(path), "-T", "fields", "-E", "separator=/t", "-E", "occurrence=a",
           "-E", "aggregator=,"] + [x for f in fields for x in ("-e", f)]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        return {"file": path.name, "error": "timeout"}
    rows = [ln.split("\t") for ln in res.stdout.splitlines() if ln.strip()]
    m = parse_rows(rows, has_ho_field=len(fields) > len(BASE_FIELDS))
    m["file"] = path.name
    return m


def find_captures(dirs: List[str]) -> List[Path]:
    out = []
    for d in dirs:
        for ext in ("*.pcapng", "*.pcap"):
            out += sorted(Path(d).rglob(ext))
    return out


# ---------------------------------------------------------------- statistics
def binom_sf(k: int, n: int, p: float) -> float:
    """P(X >= k), X ~ Bin(n, p); exact, log-space."""
    if k <= 0:
        return 1.0
    if n <= 0 or k > n:
        return 0.0
    if p <= 0:
        return 0.0
    if p >= 1:
        return 1.0
    lp, lq = math.log(p), math.log(1 - p)
    t = [math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1) + i * lp + (n - i) * lq
         for i in range(k, n + 1)]
    mx = max(t)
    return min(1.0, math.exp(mx) * sum(math.exp(x - mx) for x in t))


def aggregate(sessions: List[Dict]) -> Dict:
    ok = [s for s in sessions if "error" not in s]
    counts = {k: sum(s["counts"].get(k, 0) for s in ok) for k in COUNT_METRICS}
    hours = sum(s["duration_s"] for s in ok) / 3600.0
    return {"counts": counts, "hours": round(hours, 4), "files": len(ok)}


def compare_profiles(base: Dict, inv: Dict, alpha: float = 0.01, min_ratio: float = 3.0,
                     min_count: int = 5) -> Dict:
    Tb, Ti = base["hours"], inv["hours"]
    warn = []
    if Tb < 2:
        warn.append(f"Baseline only {Tb:.2f} h of capture (<2 h): comparison weak.")
    if Ti <= 0 or Tb <= 0:
        return {"metrics": [], "warnings": warn + ["Zero capture duration on one side."]}
    rows = []
    for k in COUNT_METRICS:
        b, i = base["counts"].get(k, 0), inv["counts"].get(k, 0)
        rb, ri = b / Tb, i / Ti
        ratio = (ri / rb) if rb > 0 else (math.inf if ri > 0 else 1.0)
        p = binom_sf(i, i + b, Ti / (Ti + Tb)) if (i + b) > 0 else 1.0
        flag = "EXCEEDS_BASELINE" if (p < alpha and ratio >= min_ratio and i >= min_count) else "consistent"
        rows.append({"metric": k, "baseline_count": b, "baseline_per_h": round(rb, 3),
                     "investigation_count": i, "investigation_per_h": round(ri, 3),
                     "rate_ratio": None if math.isinf(ratio) else round(ratio, 2),
                     "p_one_sided": p, "flag": flag})
    return {"metrics": rows, "warnings": warn, "baseline_hours": Tb, "investigation_hours": Ti}


# ---------------------------------------------------------------- modes
def mode_inventory(dirs):
    files = find_captures(dirs)
    mb = sum(f.stat().st_size for f in files) / 1048576
    q = sum(len(list(Path(d).rglob("*.qmdl"))) for d in dirs)
    print(f"PCAP/PCAPNG: {len(files)}  QMDL: {q}  PCAP size: {mb:.2f} MB")


def mode_capture(dirs, output):
    exe = _tshark()
    avail = _available_fields(exe)
    files = find_captures(dirs)
    if not files:
        sys.exit("No .pcap/.pcapng files found.")
    sessions = []
    for f in files:
        print(f"  analysing {f.name}")
        sessions.append(analyze_file(f, exe, avail))
    prof = {"generated": datetime.now(timezone.utc).isoformat(), "inputs": dirs,
            "aggregate": aggregate(sessions), "sessions": sessions}
    Path(output).write_text(json.dumps(prof, indent=2))
    a = prof["aggregate"]
    print(f"Saved {output}: {a['files']} files, {a['hours']:.2f} capture-hours")
    for k, v in a["counts"].items():
        print(f"  {k:30s} {v:8d}  ({v / a['hours']:.2f}/h)" if a["hours"] else f"  {k}: {v}")


def mode_compare(baseline, inv_dir, output):
    base = json.loads(Path(baseline).read_text())["aggregate"]
    exe = _tshark()
    avail = _available_fields(exe)
    sessions = [analyze_file(f, exe, avail) for f in find_captures([inv_dir])]
    inv = aggregate(sessions)
    res = compare_profiles(base, inv)
    res.update({"baseline_file": baseline, "investigation_dir": inv_dir,
                "generated": datetime.now(timezone.utc).isoformat(), "investigation_sessions": sessions})
    Path(output).write_text(json.dumps(res, indent=2, default=str))
    print(f"\nBaseline {base['hours']:.2f} h vs investigation {inv['hours']:.2f} h")
    for w in res["warnings"]:
        print("  WARNING:", w)
    print(f"{'metric':30s}{'base/h':>9}{'inv/h':>9}{'ratio':>8}{'p':>10}  flag")
    for r in res["metrics"]:
        print(f"{r['metric']:30s}{r['baseline_per_h']:9.2f}{r['investigation_per_h']:9.2f}"
              f"{str(r['rate_ratio']):>8}{r['p_one_sided']:10.2g}  {r['flag']}")
    print("\nNote: single-control screening only. 'consistent' != 'clean'; EXCEEDS != attribution.")
    print(f"Saved {output}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mode", choices=["inventory", "capture", "compare"], required=True)
    ap.add_argument("--input", nargs="+")
    ap.add_argument("--baseline")
    ap.add_argument("--investigation")
    ap.add_argument("--output")
    a = ap.parse_args()
    if a.mode == "inventory":
        mode_inventory(a.input or sys.exit("--input required"))
    elif a.mode == "capture":
        mode_capture(a.input or sys.exit("--input required"), a.output or "baseline_profile.json")
    else:
        if not (a.baseline and a.investigation):
            sys.exit("--baseline and --investigation required")
        mode_compare(a.baseline, a.investigation, a.output or "baseline_comparison_results.json")


if __name__ == "__main__":
    main()
