#!/usr/bin/env python3
"""
tests/test_synthetic.py — synthetic IMSI-catcher timeline through the detector chain.

pytest-collectable (the old version only defined run_tests(), so pytest collected nothing and
exited 5, failing CI). Still runnable directly:  python tests/test_synthetic.py

Runs from any working directory, never calls OpenCelliD, and writes only to a temp dir.
"""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

config_loader = pytest.importorskip("config_loader")
from detectors.identity_harvest import IdentityHarvestDetector
from detectors.cipher_downgrade import CipherDowngradeDetector
from detectors.handover_inject import HandoverInjectDetector
from detectors.paging_anomaly import PagingAnomalyDetector
from detectors.earfcn_anomaly import EarfcnAnomalyDetector
from detectors.rogue_tower import RogueTowerDetector
from intelligence.hardware_fingerprint import HardwareFingerprinter
from reporter import ThreatReporter


def make_event(**kwargs) -> dict:
    """Helper to build a synthetic normalised event."""
    defaults = {
        "source_file": "synthetic_test.ndjson",
        "source_type": "ndjson",
        "line": 0,
        "timestamp": "2026-03-31T14:00:00+00:00",
        "raw": {},
        "cell_id": "98765",
        "earfcn": 9350,
        "mcc": "505",
        "mnc": "001",
        "tac": "1234",
        "pci": 42,
        "rsrp": -72.0,
        "rat": "LTE",
        "msg_type": None,
        "msg_subtype": None,
        "layer": "NAS",
        "cipher_alg": None,
        "integrity_alg": None,
        "identity_type": None,
        "has_mobility_control": False,
        "has_geran_redirect": False,
        "has_measreport": False,
        "has_prose": False,
        "paging_type": None,
        "harness_alerts": [],
    }
    defaults.update(kwargs)
    return defaults


def build_test_events() -> list:
    """
    Build a synthetic event timeline representing a full IMSI catcher attack:
      T+0s   : Identity Request (IMSI)
      T+5s   : Identity Request (IMSI)   ← second request = flood
      T+10s  : Identity Request (IMSI)   ← third = CRITICAL
      T+12s  : Security Mode Command EEA0 + EIA0   ← full null cipher
      T+15s  : RRC Reconfig with mobilityControlInfo (no prior MeasReport)
      T+20s  : RRC Connection Release with GERAN redirect
      T+35s  : Paging (IMSI-targeted)
      T+40s  : Authentication Reject
      T+42s  : Identity Request (IMEI) after auth reject
      T+50s  : RRC Reconfig with ProSe proximity config
      — Plus same cell_id on different EARFCN (multi-EARFCN anomaly)
    """

    base_ts = "2026-03-31T14:{}:{}+00:00"

    events = [
        # 1. Identity Request flood (3 IMSI requests)
        make_event(
            timestamp=base_ts.format("00", "00"),
            msg_type="Identity Request",
            identity_type="IMSI",
        ),
        make_event(
            timestamp=base_ts.format("00", "05"),
            msg_type="Identity Request",
            identity_type="IMSI",
        ),
        make_event(
            timestamp=base_ts.format("00", "10"),
            msg_type="Identity Request",
            identity_type="IMSI",
        ),

        # 2. Full null cipher (EEA0 + EIA0)
        make_event(
            timestamp=base_ts.format("00", "12"),
            msg_type="Security Mode Command",
            cipher_alg="EEA0",
            integrity_alg="EIA0",
        ),

        # 3. Injected handover (mobilityControlInfo, no MeasReport)
        make_event(
            timestamp=base_ts.format("00", "15"),
            msg_type="RRC Connection Reconfiguration",
            has_mobility_control=True,
            has_measreport=False,
            layer="RRC",
        ),
        make_event(
            timestamp=base_ts.format("00", "16"),
            msg_type="RRC Connection Reconfiguration",
            has_mobility_control=True,
            has_measreport=False,
            layer="RRC",
        ),
        make_event(
            timestamp=base_ts.format("00", "17"),
            msg_type="RRC Connection Reconfiguration",
            has_mobility_control=True,
            has_measreport=False,
            layer="RRC",
        ),

        # 4. GERAN redirect (forced 2G downgrade)
        make_event(
            timestamp=base_ts.format("00", "20"),
            msg_type="RRC Connection Release",
            has_geran_redirect=True,
            layer="RRC",
        ),

        # 5. IMSI-targeted paging
        make_event(
            timestamp=base_ts.format("00", "35"),
            msg_type="Paging",
            paging_type="IMSI",
        ),
        make_event(
            timestamp=base_ts.format("00", "38"),
            msg_type="Paging",
            paging_type="IMSI",
        ),
        make_event(
            timestamp=base_ts.format("00", "39"),
            msg_type="Paging",
            paging_type="IMSI",
        ),

        # 6. Auth Reject → IMEI request
        make_event(
            timestamp=base_ts.format("00", "40"),
            msg_type="Authentication Reject",
        ),
        make_event(
            timestamp=base_ts.format("00", "42"),
            msg_type="Identity Request",
            identity_type="IMEI/IMEISV",
        ),

        # 7. ProSe proximity tracking config
        make_event(
            timestamp=base_ts.format("00", "50"),
            msg_type="RRC Connection Reconfiguration",
            has_prose=True,
            layer="RRC",
            harness_alerts=["reportProximityConfig-r9 detected"],
        ),

        # 8. Multi-EARFCN anomaly (same cell_id, different EARFCN)
        make_event(
            timestamp=base_ts.format("01", "00"),
            msg_type="MIB",
            earfcn=1450,   # ← Different EARFCN, same cell_id=98765
            cell_id="98765",
        ),

        # 9. Harness alert from Rayhunter itself
        make_event(
            timestamp=base_ts.format("01", "05"),
            harness_alerts=["imsi catcher suspected", "eea0 null cipher"],
            msg_type="Security Mode Command",
            cipher_alg="EEA0",
        ),
    ]

    return events



def _load_cfg(tmp_path):
    path = ROOT / "config.yaml"
    if not path.exists():
        path = ROOT / "config.yaml.example"
    cfg = config_loader.load(str(path))
    cfg.setdefault("opencellid", {}).update(enabled=False, cache_file=str(tmp_path / "cell_cache.json"))
    cfg["output_dir"] = str(tmp_path)
    cfg.setdefault("cross_session", {})["enabled"] = False
    return cfg


@pytest.fixture(scope="module")
def run(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("synthetic")
    cfg = _load_cfg(tmp)
    events = build_test_events()
    detectors = [IdentityHarvestDetector(cfg), CipherDowngradeDetector(cfg), RogueTowerDetector(cfg),
                 HandoverInjectDetector(cfg), PagingAnomalyDetector(cfg), EarfcnAnomalyDetector(cfg)]
    findings = []
    for d in detectors:
        findings.extend(d.analyze(events))
    hardware = HardwareFingerprinter(db_path=str(ROOT / "intelligence" / "db"), cfg=cfg).analyze(events, findings)
    return {"cfg": cfg, "events": events, "findings": findings, "hardware": hardware, "tmp": tmp}


def _title_has(findings, *needles, field="title"):
    return any(any(n.lower() in str(f.get(field, "")).lower() for n in needles) for f in findings)


def test_critical_findings_present(run):
    assert any(f.get("severity") == "CRITICAL" for f in run["findings"])

@pytest.mark.parametrize("label,needles,field", [
    ("identity harvest", ("identity",), "title"),
    ("null cipher", ("null", "eea0"), "title"),
    ("geran redirect", ("2g", "geran"), "title"),
    ("handover inject", ("handover", "mobility"), "title"),
    ("prose tracking", ("prose", "proximity"), "title"),
    ("imsi paging", ("paging",), "title"),
    ("multi-earfcn", ("earfcn",), "title"),
])
def test_expected_detection(run, label, needles, field):
    assert _title_has(run["findings"], *needles, field=field), f"{label} not detected"

def test_hardware_candidates(run):
    assert len(run["hardware"]) > 0

def test_reporter_builds_serialisable_report(run):
    reporter = ThreatReporter(run["cfg"])
    report = reporter.build_report({"events": run["events"], "findings": run["findings"],
                                    "hardware": run["hardware"]}, elapsed=0.1)
    (run["tmp"] / "test_report.json").write_text(json.dumps(report, default=str))


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
