#!/usr/bin/env python3
"""
OperatorRhythmProfiler (v4.4.3) — activity-rhythm profile with null-hypothesis tests.

Fixes vs v3.4:
  * DST-aware local time (Melbourne is AEDT, UTC+11, for Oct–Apr) via zoneinfo.
  * No overwriting of the inferred timezone.
  * Unit of analysis = distinct active (date, hour) slots, not raw events, so one busy
    burst can't dominate. Binomial tests vs uniform-activity null (weekday 5/7, work-hours
    share of the day). p-values are indicative only (slots are still autocorrelated).
  * Needs >= MIN_ACTIVE_DAYS active days; sparse days dropped.
  * Pre/post-event shift uses a day-level permutation test, >= 5 days each side.
  * Severity capped at MEDIUM; never asserts "human-operated confirmed". The capture device
    and the carrier's normal traffic follow human daily rhythms too (confound) — compare to a
    control via analysis.rhythm_control {biz_share, weekday_share}.
"""
import os
import random
import sys
from collections import defaultdict
from datetime import datetime, timezone
from math import lgamma, log, exp
from typing import Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from detectors.base import BaseDetector, make_finding
from forensic_time import normalize_epoch_seconds, trusted_timestamp, local_tz, active_days

MIN_ACTIVE_DAYS = 7
EVENT_DATES = {"ACMA inspection": "2026-05-08", "VicPol referral": "2026-03-31"}


def binom_sf(k: int, n: int, p: float) -> float:
    """P(X >= k), X~Bin(n,p), log-space exact."""
    if n <= 0 or k <= 0:
        return 1.0
    if k > n:
        return 0.0
    lp, lq = log(p), log(1 - p)
    terms = [lgamma(n + 1) - lgamma(i + 1) - lgamma(n - i + 1) + i * lp + (n - i) * lq
             for i in range(k, n + 1)]
    m = max(terms)
    return min(1.0, exp(m) * sum(exp(t - m) for t in terms))


def longest_quiet_run(active_hours: set) -> Optional[Dict]:
    """Longest circular run of local hours with zero active slots (>= 3h)."""
    quiet = [h for h in range(24) if h not in active_hours]
    if len(quiet) < 3 or len(quiet) == 24:
        return None
    best_len, best_start = 0, 0
    for s in range(24):
        if s in quiet and (s - 1) % 24 not in quiet:
            n = 0
            while (s + n) % 24 in quiet:
                n += 1
            if n > best_len:
                best_len, best_start = n, s
    return {"start": best_start, "end": (best_start + best_len) % 24, "hours": best_len} if best_len >= 3 else None


def perm_test_shift(pre: List[float], post: List[float], n_perm: int = 2000) -> float:
    obs = abs(sum(pre) / len(pre) - sum(post) / len(post))
    pool, k = pre + post, len(pre)
    rng, hits = random.Random(0), 0
    for _ in range(n_perm):
        rng.shuffle(pool)
        if abs(sum(pool[:k]) / k - sum(pool[k:]) / (len(pool) - k)) >= obs:
            hits += 1
    return (hits + 1) / (n_perm + 1)


class OperatorRhythmProfiler(BaseDetector):
    name = "OperatorRhythmProfiler"
    description = "Activity rhythm profile with null-hypothesis tests (indicative, control-dependent)"

    @staticmethod
    def _epoch(ev: Dict) -> Optional[float]:
        ts = ev.get("timestamp") or ev.get("time") or ev.get("ts")
        if ts is None:
            return None
        try:
            if isinstance(ts, (int, float)):
                return normalize_epoch_seconds(float(ts))
            dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return normalize_epoch_seconds(dt.timestamp())
        except (ValueError, OSError, OverflowError):
            return None

    def analyze(self, events: List[Dict]) -> List[Dict]:
        acfg = self.cfg.get("analysis", {}) or {}
        tz = local_tz(acfg.get("local_timezone", "Australia/Melbourne"))
        w0, w1 = acfg.get("work_hours", [8, 18])
        min_ev = int(acfg.get("min_events_per_day", 50))

        epochs = [t for t in (self._epoch(e) for e in events if trusted_timestamp(e)) if t is not None]
        kept, dropped = active_days(epochs, min_ev, tz)
        if len(kept) < MIN_ACTIVE_DAYS:
            return []

        slots = set()
        for e in epochs:
            dt = datetime.fromtimestamp(e, tz=tz)
            d = dt.strftime("%Y-%m-%d")
            if d in kept:
                slots.add((d, dt.hour, dt.weekday()))
        n = len(slots)
        if n == 0:
            return []

        hour_hist = defaultdict(int)
        day_hours = defaultdict(list)
        wk = 0
        biz = 0
        for d, h, wd in slots:
            hour_hist[h] += 1
            day_hours[d].append(h)
            wk += wd < 5
            biz += w0 <= h < w1
        wd_share, biz_share = wk / n, biz / n
        p_wd = binom_sf(wk, n, 5 / 7)
        p_biz = binom_sf(biz, n, (w1 - w0) / 24)
        quiet = longest_quiet_run(set(hour_hist))

        # pre/post shift (day-level mean active hour)
        shifts = []
        for label, dstr in EVENT_DATES.items():
            pre = [sum(v) / len(v) for d, v in day_hours.items() if d < dstr]
            post = [sum(v) / len(v) for d, v in day_hours.items() if d >= dstr]
            if len(pre) >= 5 and len(post) >= 5:
                diff = abs(sum(pre) / len(pre) - sum(post) / len(post))
                p = perm_test_shift(pre, post)
                shifts.append((label, diff, p, len(pre), len(post)))

        ctrl = acfg.get("rhythm_control") or {}
        ctrl_note, beats_control = "No control rhythm supplied (analysis.rhythm_control) — confound unresolved.", None
        if ctrl:
            db = biz_share - float(ctrl.get("biz_share", 0))
            dw = wd_share - float(ctrl.get("weekday_share", 0))
            beats_control = db >= 0.15 or dw >= 0.15
            ctrl_note = f"Versus control: work-hours share {db:+.0%}, weekday share {dw:+.0%}."

        ev = [f"Active local days (>= {min_ev} events): {len(kept)}; sparse days dropped: {len(dropped)}",
              f"Active (date,hour) slots analysed: {n:,}  (tz: {getattr(tz, 'key', 'UTC+10 fixed')}, DST-aware)",
              f"Weekday share of active slots: {wd_share:.1%} (null 71.4%; binomial p={p_wd:.3g})",
              f"Work-hours ({w0:02d}-{w1:02d}) share: {biz_share:.1%} (null {(w1-w0)/24:.1%}; p={p_biz:.3g})",
              ctrl_note]
        if quiet:
            ev.append(f"Longest zero-activity window (local): {quiet['start']:02d}:00-{quiet['end']:02d}:00 ({quiet['hours']}h)")
        for label, diff, p, a, b in shifts:
            ev.append(f"Shift around {label}: mean active hour moved {diff:.1f}h (permutation p={p:.3g}, {a} pre / {b} post days)")
        if not shifts:
            ev.append("Pre/post-event shift: not tested (need >= 5 active days on each side).")
        mx = max(hour_hist.values())
        ev.append("Active-slot histogram (local hour):")
        ev += [f"  {h:02d}:00 [{'#' * int(hour_hist.get(h, 0) / mx * 30):<30}] {hour_hist.get(h, 0)}" for h in range(24)]
        ev.append("CAVEAT: capture device + carrier traffic follow human daily rhythms; tests above are vs a "
                  "uniform null, not vs a control. Slots are autocorrelated, so p-values are indicative only.")

        strong = p_wd < 0.01 and p_biz < 0.01
        if ctrl and not beats_control:
            severity, confidence = "LOW", "SUSPECTED"
        elif strong:
            severity, confidence = "MEDIUM", "PROBABLE" if (ctrl and beats_control) else "SUSPECTED"
        else:
            severity, confidence = "LOW", "SUSPECTED"

        return [make_finding(
            detector=self.name,
            title="Activity Rhythm Profile",
            description=(f"Activity over {len(kept)} active days concentrates in work hours "
                         f"({biz_share:.0%}) and weekdays ({wd_share:.0%}) vs uniform-null expectations. "
                         "This does not by itself distinguish an operator from device-owner or network "
                         "activity; a control capture is required."),
            severity=severity, confidence=confidence,
            technique="Temporal activity analysis vs null hypothesis",
            evidence=ev,
            action=("1. Run the same pipeline on a control capture and put its biz_share/weekday_share "
                    "in analysis.rhythm_control.\n2. Do not describe this as operator attribution unless it "
                    "clearly exceeds the control."),
            spec_ref="Statistical analysis; no 3GPP reference",
            metrics={"biz_share": round(biz_share, 4), "weekday_share": round(wd_share, 4),
                     "active_days": len(kept), "slots": n},
        )]
