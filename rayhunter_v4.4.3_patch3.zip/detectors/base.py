#!/usr/bin/env python3
"""Base class for all threat detectors (v4.4.3)."""
from abc import ABC, abstractmethod
from typing import List, Dict
from datetime import datetime, timezone

try:
    from forensic_time import normalize_epoch_seconds
except Exception:                      # pragma: no cover
    normalize_epoch_seconds = None

SEVERITY_LEVELS = {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}
CONFIDENCE_LEVELS = {"CONFIRMED": 3, "PROBABLE": 2, "SUSPECTED": 1}


def get_msg_type(ev: Dict) -> str:
    """Normalised events use 'msg_type'; some paths use 'message_type'. Accept both."""
    return str(ev.get("msg_type") or ev.get("message_type") or "")


def get_cell_id(ev: Dict) -> str:
    return str(ev.get("cell_id") or ev.get("cid") or "")


def make_finding(
    detector: str,
    title: str,
    description: str,
    severity: str,
    confidence: str,
    technique: str,
    evidence: List[str],
    events: List[Dict] = None,
    hardware_hint: str = None,
    action: str = None,
    cve: str = None,
    spec_ref: str = None,
    data_source: str = None,      # was passed by OperationalProfileSynthesiser -> TypeError before
    **extra,                      # detector-specific fields (e.g. metrics={...})
) -> Dict:
    """Construct a standardised threat finding dict."""
    f = {
        "detector": detector,
        "title": title,
        "description": description,
        "severity": severity,
        "severity_score": SEVERITY_LEVELS.get(severity, 0),
        "confidence": confidence,
        "confidence_score": CONFIDENCE_LEVELS.get(confidence, 0),
        "technique": technique,
        "evidence": evidence,
        "event_count": len(events) if events else 0,
        "hardware_hint": hardware_hint,
        "recommended_action": action,
        "spec_reference": spec_ref,
        "data_source": data_source,
        "found_at": datetime.now(timezone.utc).isoformat(),
    }
    f.update(extra)
    return f


class BaseDetector(ABC):
    name = "BaseDetector"
    description = ""

    def __init__(self, cfg: dict):
        self.cfg = cfg or {}
        self.thresholds = self.cfg.get("thresholds", {})

    @abstractmethod
    def analyze(self, events: List[Dict]) -> List[Dict]:
        """Analyze normalised events, return list of findings."""

    def filter_by_type(self, events: List[Dict], msg_types: List[str]) -> List[Dict]:
        wanted = [m.lower() for m in msg_types]
        return [e for e in events if any(m in get_msg_type(e).lower() for m in wanted)]

    def parse_timestamp(self, ev: Dict) -> float:
        """Unix float, or 0.0 if missing/implausible (epoch-zero, garbage years)."""
        ts = ev.get("timestamp")
        if not ts:
            return 0.0
        val = None
        try:
            from dateutil import parser as dtparser
            dt = dtparser.parse(str(ts))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            val = dt.timestamp()
        except Exception:
            try:
                val = float(str(ts))
            except (ValueError, TypeError):
                return 0.0
        if normalize_epoch_seconds is not None:
            n = normalize_epoch_seconds(val)
            return n if n is not None else 0.0
        return val
