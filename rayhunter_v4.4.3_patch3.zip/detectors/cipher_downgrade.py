#!/usr/bin/env python3
"""
Cipher Downgrade Detector (v4.4.3)
==================================
Null-cipher/integrity selection in Security Mode Command and explicit GERAN redirects.

v4.4.3 changes (see CHANGELOG_4.4.3.md):
  * REMOVED substring matching on str(event["raw"]). It set has_geran_redirect on any message whose
    raw text contained "geran" (UE capabilities, SIB7 neighbour info), has_mobility_control on any
    mention of "handover", has_prose on "proximity", and promoted EEA0/EIA0 from the *replayed UE
    security capabilities* (which list EEA0/EIA0 support) into "selected algorithm". Those mutated
    the shared event list, so downstream detectors inherited the false flags.
  * Only structured parser fields / `threats` tags are promoted, and only onto the right message type.
  * GERAN rule requires an RRC Connection Release carrying the redirect flag (no fallback to arbitrary
    events). A5/0 rule no longer treats LTE EEA0 as A5/0.
  * "SMC without authentication" is evaluated per file, MEDIUM/SUSPECTED: LTE can reuse an existing
    security context, so SMC without a fresh AKA is not inherently abnormal.
  * EEA0-only is MEDIUM/PROBABLE (EEA0 is mandatory to implement and its selection is operator policy,
    unlike EIA0 which TS 33.401 restricts to unauthenticated emergency sessions — verify in spec).
  * No case-specific narrative or contradictory "likely a false positive" text in findings.
"""
from typing import List, Dict
from .base import BaseDetector, make_finding, get_msg_type


def _is_smc(e: Dict) -> bool:
    return "security mode command" in get_msg_type(e).lower()


class CipherDowngradeDetector(BaseDetector):
    name = "CipherDowngradeDetector"
    description = "Detects explicit null-cipher/integrity selection and GERAN redirects"

    def analyze(self, events: List[Dict]) -> List[Dict]:
        findings: List[Dict] = []

        # Promote only structured parser tags (no raw-text substring matching).
        for e in events:
            threats = e.get("threats", []) or []
            if "NULL_CIPHER" in threats and not e.get("cipher_alg") and _is_smc(e):
                e["cipher_alg"], e["integrity_alg"] = "EEA0", e.get("integrity_alg") or "EIA0"
            if ("GERAN_REDIRECT" in threats or "SIB_DOWNGRADE" in threats) and "release" in get_msg_type(e).lower():
                e["has_geran_redirect"] = True
            if "PROSE_TRACKING" in threats:
                e["has_prose"] = True
            if "HANDOVER_INJECT" in threats:
                e["has_mobility_control"] = True

        smc = [e for e in events if _is_smc(e)]
        eea0 = lambda e: str(e.get("cipher_alg", "")).upper() == "EEA0"
        eia0 = lambda e: str(e.get("integrity_alg", "")).upper() == "EIA0"
        full_null = [e for e in smc if eea0(e) and eia0(e)]
        eea0_only = [e for e in smc if eea0(e) and e.get("integrity_alg") not in (None, "") and not eia0(e)]
        eia0_only = [e for e in smc if eia0(e) and e.get("cipher_alg") not in (None, "") and not eea0(e)]

        if full_null:
            findings.append(make_finding(
                detector=self.name, title="Null Cipher and Null Integrity Selected (EEA0 + EIA0)",
                description=(f"{len(full_null)} Security Mode Command(s) selected EEA0 and EIA0. EIA0 is restricted "
                             "to unauthenticated emergency sessions (TS 33.401), so selection outside that context "
                             "is a strong anomaly. Confirm the algorithms are the SELECTED ones in the SMC, not the "
                             "replayed UE capability list, and rule out an emergency attach."),
                severity="CRITICAL", confidence="CONFIRMED",
                technique="Null cipher + null integrity selection", evidence=self._fmt(full_null), events=full_null,
                action=("1. Decode the SMC in Wireshark and note the selected NAS/AS algorithms.\n"
                        "2. Check for an emergency/unauthenticated attach context.\n"
                        "3. Preserve the QMDL/PCAP with its hash."),
                spec_ref="3GPP TS 33.401 §5.1.3, TS 24.301 §5.4.3"))
        if eea0_only:
            findings.append(make_finding(
                detector=self.name, title="Null Encryption (EEA0) Selected in Security Mode Command",
                description=(f"{len(eea0_only)} SMC(s) selected EEA0 with a non-null integrity algorithm. EEA0 is "
                             "mandatory to implement and some deployments permit it, so this is unusual rather than "
                             "inherently illegitimate. Compare with a control capture on the same operator."),
                severity="MEDIUM", confidence="PROBABLE", technique="Null encryption selection",
                evidence=self._fmt(eea0_only), events=eea0_only, spec_ref="3GPP TS 33.401 §5.1.3"))
        if eia0_only:
            findings.append(make_finding(
                detector=self.name, title="Null Integrity (EIA0) Selected in Security Mode Command",
                description=(f"{len(eia0_only)} SMC(s) selected EIA0 with a non-null cipher. Outside unauthenticated "
                             "emergency sessions this is abnormal."),
                severity="HIGH", confidence="PROBABLE", technique="Null integrity selection",
                evidence=self._fmt(eia0_only), events=eia0_only, spec_ref="3GPP TS 33.401 §5.1.3"))

        # GERAN redirect: explicit flag on an RRC Connection Release only
        geran = [e for e in self.filter_by_type(events, ["RRC Connection Release"]) if e.get("has_geran_redirect")]
        if geran:
            findings.append(make_finding(
                detector=self.name, title="RRC Connection Release with GERAN Redirect",
                description=(f"{len(geran)} RRC Connection Release message(s) carried a GERAN redirectedCarrierInfo. "
                             "Redirects to GSM are used for CS fallback and are anomalous where 2G is decommissioned "
                             "(verify current status for this operator). Confirm the IE in the decode."),
                severity="HIGH", confidence="PROBABLE", technique="Redirect to GERAN",
                evidence=self._fmt(geran), events=geran,
                action="Decode the Release in Wireshark; record the target ARFCN and the preceding NAS context.",
                spec_ref="3GPP TS 36.331 §5.3.8"))

        # A5/0: GSM-layer message only (never LTE EEA0)
        gsm = [e for e in events if str(e.get("cipher_alg", "")).upper() in ("A5/0", "A50")]
        if gsm:
            findings.append(make_finding(
                detector=self.name, title="GSM A5/0 (no cipher) observed",
                description=f"{len(gsm)} event(s) report GSM A5/0.", severity="HIGH", confidence="PROBABLE",
                technique="GSM null cipher", evidence=self._fmt(gsm), events=gsm, spec_ref="3GPP TS 43.020"))

        # SMC without any Authentication earlier in the same file
        by_file: Dict[str, Dict[str, List[Dict]]] = {}
        for e in events:
            m = get_msg_type(e).lower()
            if "security mode command" in m or "authentication request" in m or "authentication response" in m:
                by_file.setdefault(str(e.get("source_file", "")), {"smc": [], "auth": []})[
                    "smc" if "security mode command" in m else "auth"].append(e)
        orphan = [s for d in by_file.values() if d["smc"] and not d["auth"] for s in d["smc"]]
        if orphan:
            findings.append(make_finding(
                detector=self.name, title="Security Mode Command with no Authentication in same file",
                description=(f"{len(orphan)} SMC(s) in capture file(s) containing no Authentication Request/Response. "
                             "LTE may reuse an existing security context (no new AKA), and captures can start "
                             "mid-session, so this alone is not abnormal."),
                severity="MEDIUM", confidence="SUSPECTED", technique="SMC without visible AKA",
                evidence=self._fmt(orphan[:3]), events=orphan, spec_ref="3GPP TS 33.401 §6.1, TS 24.301 §5.4.3"))
        return findings

    def _fmt(self, events: List[Dict]) -> List[str]:
        return [f"[{e.get('timestamp') or (e.get('raw') or {}).get('packet_timestamp', '?')}] "
                f"{get_msg_type(e) or '?'} | EEA={e.get('cipher_alg', '?')} EIA={e.get('integrity_alg', '?')} "
                f"({e.get('source_file', '')})" for e in events[:6]]
