#!/usr/bin/env python3
"""
Identity Harvest Detector (v4.4.3)
==================================
Flags unusual NAS Identity Request patterns.

v4.4.3 changes (see CHANGELOG_4.4.3.md):
  * Reads detection.identity_harvest.{window_seconds,max_requests,flag_imeisv} (the old code read a
    top-level `thresholds:` block that does not exist in config.yaml, so config was ignored).
  * No case-specific narrative (pcap names, frame numbers, ACMA refs, "Harris") in finding text.
  * Flood rule needs valid timestamps. With none, it reports MEDIUM/SUSPECTED on count alone
    (previously CRITICAL/CONFIRMED) and untimed events no longer match "within 10 s" of anything.
  * Windows are evaluated per source file (no cross-file coincidences from merged corpora).
  * IMEISV/IMEI requests are not asserted to be illegitimate: networks can request them (equipment
    checks). Severity depends on whether the request was sent before NAS security (plain header).
  * "Unprovoked" rule now works per request using preceding uplink Attach/TAU/Service requests, and
    reports INFO (cannot assess) when no uplink NAS was captured at all.
  * Findings built from Rayhunter's own alert strings (circular) are capped at MEDIUM/SUSPECTED.
Reference: 3GPP TS 24.301 §5.4.4 (identification procedure).
"""
from typing import List, Dict, Optional
from .base import BaseDetector, make_finding, get_msg_type

UL_NAS_TYPES = ["Attach Request", "Tracking Area Update Request", "Service Request",
                "Extended Service Request"]


def _plain(e: Dict) -> Optional[bool]:
    """True = plain NAS (pre-security), False = integrity protected, None = unknown."""
    v = e.get("security_header_type")
    if v is None:
        v = e.get("nas_security_header")
    if v is None:
        return None
    try:
        return int(str(v), 0) == 0
    except ValueError:
        return None


class IdentityHarvestDetector(BaseDetector):
    name = "IdentityHarvestDetector"
    description = "Detects unusual Identity Request sequences (IMSI/IMEI/IMEISV)"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        c = ((cfg or {}).get("detection", {}) or {}).get("identity_harvest", {}) or {}
        t = self.thresholds or {}
        self.window = float(c.get("window_seconds", t.get("identity_request_window_seconds", 120)))
        self.max_normal = int(c.get("max_requests", t.get("identity_request_max_normal", 2)))
        self.flag_imeisv = bool(c.get("flag_imeisv", True))

    # ------------------------------------------------------------------
    def analyze(self, events: List[Dict]) -> List[Dict]:
        findings: List[Dict] = []
        id_reqs = self.filter_by_type(events, ["Identity Request"])
        derived = False
        if not id_reqs:
            id_reqs = [e for e in events
                       if "IMSI_HARVEST" in e.get("threats", []) or "IMSI_EXPOSURE_CONTEXT" in e.get("threats", [])
                       or any("imsi" in str(a).lower() or "identity" in str(a).lower()
                              for a in e.get("harness_alerts", []))]
            derived = True       # derived from Rayhunter's own alert text -> circular, cap severity
        if not id_reqs:
            return findings

        imsi = [e for e in id_reqs if e.get("identity_type") in ("IMSI", None)]
        imeisv = [e for e in id_reqs if e.get("identity_type") in ("IMEISV", "IMEI/IMEISV")]
        imei = [e for e in id_reqs if e.get("identity_type") == "IMEI"]
        tmsi = [e for e in id_reqs if e.get("identity_type") in ("TMSI", "GUTI")]
        cap = (lambda sev, conf: ("MEDIUM", "SUSPECTED")) if derived else (lambda sev, conf: (sev, conf))

        # Rule 1/2: IMEISV / IMEI requests
        for label, group, code in (("IMEISV", imeisv, "3"), ("IMEI", imei, "2")):
            if not group or (label == "IMEISV" and not self.flag_imeisv):
                continue
            plain = [e for e in group if _plain(e) is True]
            known = [e for e in group if _plain(e) is not None]
            if plain:
                sev, conf = cap("MEDIUM", "PROBABLE")
                note = f"{len(plain)} of {len(group)} were plain (pre-security) NAS."
            elif known:
                sev, conf = "LOW", "SUSPECTED"
                note = "All were integrity-protected (post-security), which is common network behaviour."
            else:
                sev, conf = cap("LOW", "SUSPECTED")
                note = "NAS security state not available in parsed events, so pre/post-security is unknown."
            findings.append(make_finding(
                detector=self.name,
                title=f"{label} Identity Request(s) — {len(group)} Event(s)",
                description=(f"{len(group)} NAS Identity Request(s) for {label} (identity type {code}). {note} "
                             "Networks can request equipment identities for legitimate checks; this is a lead "
                             "that needs context (what preceded it, whether the request was protected)."),
                severity=sev, confidence=conf, technique=f"{label} identity solicitation",
                evidence=self._fmt(group), events=group,
                action=("1. Decode the frames in Wireshark; record security header type and preceding messages.\n"
                        "2. Compare request rate with a control capture (baseline_comparison.py)."),
                spec_ref="3GPP TS 24.301 §5.4.4"))

        # Rule 3: IMSI requests in a window, per source file
        if len(imsi) > self.max_normal:
            by_file: Dict[str, List[Dict]] = {}
            for e in imsi:
                by_file.setdefault(str(e.get("source_file", "")), []).append(e)
            best, best_file, timed_any = 0, "", False
            for fname, evs in by_file.items():
                ts = [t for t in (self.parse_timestamp(e) for e in evs) if t > 0]
                if ts:
                    timed_any = True
                    n = self._count_in_window(ts, self.window)
                    if n > best:
                        best, best_file = n, fname
            plain_n = sum(1 for e in imsi if _plain(e) is True)
            if timed_any and best > self.max_normal:
                sev, conf = cap("HIGH", "PROBABLE")
                findings.append(make_finding(
                    detector=self.name, title="Repeated IMSI Identity Requests",
                    description=(f"Up to {best} IMSI Identity Requests within {self.window:.0f}s in one capture "
                                 f"file ({best_file or 'unnamed'}); threshold {self.max_normal}. "
                                 f"{plain_n} of {len(imsi)} IMSI requests are known plain/pre-security. "
                                 "Repeated requests also occur legitimately (unknown GUTI after an MME change, "
                                 "repeated attach attempts); compare with a control capture."),
                    severity=sev, confidence=conf, technique="Repeated identity solicitation",
                    evidence=self._fmt(imsi[:8]), events=imsi,
                    action=("1. Check in tshark what preceded each request (reject cause, GUTI, cell change).\n"
                            "2. Run the same analysis on a control capture before relying on the count."),
                    spec_ref="3GPP TS 24.301 §5.4.4"))
            elif not timed_any:
                findings.append(make_finding(
                    detector=self.name, title="IMSI Identity Requests — timing unavailable",
                    description=(f"{len(imsi)} IMSI Identity Requests but no valid timestamps, so burst timing "
                                 "cannot be assessed. Count alone is not a flood indicator."),
                    severity="MEDIUM", confidence="SUSPECTED", technique="Identity request count (untimed)",
                    evidence=self._fmt(imsi[:6]), events=imsi,
                    action="Fix/parse capture timestamps, then re-run."))
        elif len(imsi) == 1:
            findings.append(make_finding(
                detector=self.name, title="Single IMSI Identity Request",
                description="A single IMSI Identity Request. Not conclusive alone.",
                severity="LOW", confidence="SUSPECTED", technique="Identity Request",
                evidence=self._fmt(imsi[:2]), events=imsi, spec_ref="3GPP TS 24.301 §5.4.4"))

        # Rule 4: requests with no preceding uplink Attach/TAU/Service request (per request, per file)
        ul = self.filter_by_type(events, UL_NAS_TYPES)
        sensitive = imsi + imeisv + imei
        if sensitive and not ul:
            findings.append(make_finding(
                detector=self.name, title="Identity Request context not assessable (no uplink NAS captured)",
                description=("No Attach/TAU/Service Request was captured, so whether identity requests were "
                             "preceded by a UE procedure cannot be assessed. Not evidence either way."),
                severity="INFO", confidence="SUSPECTED", technique="Capture-completeness check",
                evidence=[], events=[]))
        elif sensitive:
            ul_by_file: Dict[str, List[float]] = {}
            for e in ul:
                t = self.parse_timestamp(e)
                if t > 0:
                    ul_by_file.setdefault(str(e.get("source_file", "")), []).append(t)
            orphans = []
            for e in sensitive:
                t = self.parse_timestamp(e)
                if t <= 0:
                    continue
                prior = [u for u in ul_by_file.get(str(e.get("source_file", "")), []) if 0 <= t - u <= 60]
                if not prior:
                    orphans.append(e)
            if orphans:
                sev, conf = cap("MEDIUM", "SUSPECTED")
                findings.append(make_finding(
                    detector=self.name, title="Identity Request(s) with no uplink NAS in preceding 60 s",
                    description=(f"{len(orphans)} identity request(s) had no Attach/TAU/Service Request in the "
                                 "preceding 60 s of the same file. The identification procedure is not restricted "
                                 "to attach, and uplink capture can be incomplete, so this is a lead only."),
                    severity=sev, confidence=conf, technique="Identity request without visible trigger",
                    evidence=self._fmt(orphans[:4]), events=orphans, spec_ref="3GPP TS 24.301 §5.4.4"))

        # Rule 5: identity request shortly after Authentication Reject (both timestamps must be valid)
        auth_rej = [(e, self.parse_timestamp(e)) for e in self.filter_by_type(events, ["Authentication Reject"])]
        for ar, ar_ts in auth_rej:
            if ar_ts <= 0:
                continue
            nearby = [r for r in id_reqs if (t := self.parse_timestamp(r)) > 0 and abs(t - ar_ts) < 10
                      and r.get("source_file") == ar.get("source_file")]
            if nearby:
                sev, conf = cap("HIGH", "PROBABLE")
                findings.append(make_finding(
                    detector=self.name, title="Identity Request Near Authentication Reject",
                    description=("An Identity Request occurred within 10 s of an Authentication Reject in the "
                                 "same file. Reported as a sequence worth decoding, not as proof of an attack."),
                    severity=sev, confidence=conf, technique="Auth Reject / Identity Request sequence",
                    evidence=self._fmt([ar] + nearby), events=[ar] + nearby,
                    spec_ref="3GPP TS 24.301 §5.4.2.5, §5.4.4"))
                break
        return findings

    # ------------------------------------------------------------------
    @staticmethod
    def _count_in_window(timestamps: List[float], window: float) -> int:
        ts = sorted(timestamps)
        best, start = 1 if ts else 0, 0
        for end in range(len(ts)):
            while ts[end] - ts[start] > window:
                start += 1
            best = max(best, end - start + 1)
        return best

    def _fmt(self, events: List[Dict]) -> List[str]:
        out = []
        for e in events[:6]:
            ts = e.get("timestamp") or (e.get("raw") or {}).get("packet_timestamp", "?")
            line = f"[{ts}] {get_msg_type(e) or 'Identity Request'} id_type={e.get('identity_type', 'unknown')}"
            if _plain(e) is not None:
                line += " plain" if _plain(e) else " protected"
            if e.get("cell_id"):
                line += f" cell={e['cell_id']}"
            if e.get("source_file"):
                line += f" ({e['source_file']})"
            out.append(line)
        return out
