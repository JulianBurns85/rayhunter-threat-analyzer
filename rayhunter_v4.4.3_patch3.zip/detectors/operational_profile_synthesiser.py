#!/usr/bin/env python3
"""
OperationalProfileSynthesiser (v4.4.3) — summary of what THIS run actually found.

Changes from v3.5:
  * Every number is derived from detector findings / events. Nothing is hardcoded.
  * Hardware attribution, address, operator hours, case refs come ONLY from an optional
    `case_context:` block in config (kept out of source control) and are labelled as
    analyst-supplied, not measured.
  * Techniques with no supporting finding are omitted (no "0 events" lines).
  * Severity/confidence follow the evidence (never fixed CRITICAL/CONFIRMED).
  * "Days" = active local days with enough events, not min-max wall span.
"""
import os
import re
import sys
from datetime import datetime, timezone
from typing import Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from detectors.base import BaseDetector, make_finding, get_msg_type, get_cell_id
from forensic_time import (normalize_epoch_seconds, trusted_timestamp, local_tz,
                           active_days, contiguous_bursts)

# label, detector-name keys, title keys
TECHNIQUES = [
    ("Pre-security IMSI Identity Requests", ("wallet",), ("pre-security imsi", "imsi identity", "identity request")),
    ("Handover commands without MeasurementReport", ("handoverinject",), ("handover inject", "forced handover")),
    ("ProSe proximity configuration", ("proximitytrack",), ("prose",)),
    ("Null cipher/integrity selected", ("cipherdowngrade",), ("null cipher", "eea0")),
    ("Forced redirect / downgrade", (), ("geran", "2g redirect", "forced 2g")),
]
EXCLUDE_TITLE = ("unconfirmed", "not captured", "no evidence")
RANK = {"CONFIRMED": 3, "PROBABLE": 2, "SUSPECTED": 1}


class OperationalProfileSynthesiser(BaseDetector):
    name = "OperationalProfileSynthesiser"
    description = "Evidence-derived run summary (no hardcoded attribution)"

    def set_findings(self, findings: List[Dict]) -> None:
        self._all_findings = findings or []

    # ---- helpers ---------------------------------------------------------
    @staticmethod
    def _count(f: Dict) -> int:
        n = int(f.get("event_count") or 0)
        if n:
            return n
        m = re.search(r"(\d[\d,]*)\s*(?:pre-security|identity|imsi|rrc|event|message|injected|confirmed)",
                      str(f.get("description", "")).lower())
        return int(m.group(1).replace(",", "")) if m else 0

    def _match(self, det_keys, title_keys) -> List[Dict]:
        out = []
        for f in getattr(self, "_all_findings", []):
            if f.get("detector") == self.name:
                continue
            title = str(f.get("title", "")).lower()
            det = str(f.get("detector", "")).lower()
            if any(x in title for x in EXCLUDE_TITLE):
                continue
            if str(f.get("severity", "")).upper() == "INFO":
                continue
            if str(f.get("confidence", "")).upper() not in ("CONFIRMED", "PROBABLE"):
                continue
            if any(k in det for k in det_keys) or any(k in title for k in title_keys):
                out.append(f)
        return out

    @staticmethod
    def _epoch(ev: Dict) -> Optional[float]:
        ts = ev.get("timestamp") or ev.get("time") or ev.get("ts")
        if ts is None:
            return None
        try:
            if isinstance(ts, (int, float)):
                return normalize_epoch_seconds(float(ts))
            dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return normalize_epoch_seconds(dt.timestamp())
        except (ValueError, OSError, OverflowError):
            return None

    # ---- main ------------------------------------------------------------
    def analyze(self, events: List[Dict]) -> List[Dict]:
        acfg = self.cfg.get("analysis", {}) or {}
        ctx = self.cfg.get("case_context", {}) or {}
        tz = local_tz(acfg.get("local_timezone", "Australia/Melbourne"))
        min_ev = int(acfg.get("min_events_per_day", 50))

        epochs = [t for t in (self._epoch(e) for e in events if trusted_timestamp(e)) if t is not None]
        excluded_ts = len(events) - len(epochs)
        if not epochs:
            return []

        kept, dropped = active_days(epochs, min_ev, tz)
        bursts = contiguous_bursts(kept) if kept else []

        # techniques actually supported by findings
        rows, best_conf, any_confirmed = [], 0, False
        for label, det_keys, title_keys in TECHNIQUES:
            fs = self._match(det_keys, title_keys)
            if not fs:
                continue
            n = sum(self._count(f) for f in fs)
            conf = max((str(f.get("confidence")).upper() for f in fs), key=lambda c: RANK.get(c, 0))
            best_conf = max(best_conf, RANK.get(conf, 0))
            any_confirmed |= conf == "CONFIRMED"
            cnt = f"{n:,} event(s)" if n else "count not extractable"
            rows.append(f"  - {label}: {cnt} [{conf}; {fs[0].get('detector')}]")

        # config-listed CIDs seen (membership is NOT confirmation)
        listed = set(map(str, ((self.cfg.get("detection", {}) or {}).get("rogue_tower", {}) or {})
                         .get("known_rogue_cids", []) or []))
        seen = {get_cell_id(e) for e in events} & listed

        validated = bool(acfg.get("control_validated", False))
        if not rows:
            severity, confidence = "LOW", "SUSPECTED"
        elif any_confirmed:
            severity = "HIGH"
            confidence = "CONFIRMED" if validated else "PROBABLE"
        else:
            severity, confidence = "MEDIUM", "SUSPECTED"

        L = ["=" * 70, "  RUN SUMMARY (derived from this analysis run only)", "=" * 70, ""]
        L.append("CAPTURE COVERAGE:")
        L.append(f"  Events analysed: {len(events):,} ({excluded_ts:,} excluded: untrusted/invalid timestamps)")
        if kept:
            L.append(f"  Active local days (>= {min_ev} events): {len(kept)} "
                     f"({min(kept)} to {max(kept)}, tz {getattr(tz, 'key', 'UTC+10 fixed')})")
            for a, b, n in bursts:
                L.append(f"    burst: {a} -> {b} ({n} day{'s' if n > 1 else ''})")
        if dropped:
            L.append(f"  Sparse days dropped as stray/mis-anchored: {len(dropped)} "
                     f"({sum(dropped.values()):,} events)")
        L.append("")
        L.append("OBSERVED TECHNIQUES (detector findings at CONFIRMED/PROBABLE only):")
        L.extend(rows or ["  (none supported by findings in this run)"])
        if listed:
            L.append(f"  Config-listed CIDs seen in this capture: {len(seen)}/{len(listed)} "
                     f"(list membership is not confirmation)")
        L.append("")
        if ctx:
            L.append("ANALYST-SUPPLIED CONTEXT (not derived from this capture):")
            for k in ("subject_address", "hypotheses", "references"):
                v = ctx.get(k)
                if v:
                    L.append(f"  {k}: {', '.join(v) if isinstance(v, list) else v}")
            L.append("")
        L.append("LIMITATIONS:")
        L.append("  - Pre-security Identity Requests can be legitimate (unknown GUTI, MME change);")
        L.append("    each needs preceding-message review in tshark.")
        L.append("  - No control capture applied" if not validated else "  - Control capture validated (per config)")
        L.append("  - This summary restates tool output; it is not independent evidence.")
        L.append(f"Generated: {datetime.now(timezone.utc).isoformat()}")
        L.append("=" * 70)

        f = make_finding(
            detector=self.name,
            data_source="derived_from_findings",
            title=f"Run Summary — {len(rows)} technique(s) supported, {len(kept)} active day(s)",
            description=(f"Summary of {len(events):,} events over {len(kept)} active local day(s). "
                         + ("Supported: " + "; ".join(r.strip("- ").split(" [")[0] for r in rows) + "."
                            if rows else "No technique is supported at CONFIRMED/PROBABLE.")),
            severity=severity, confidence=confidence,
            technique="Consolidation of detector findings",
            evidence=L,
            action=("1. Verify each pre-security Identity Request in tshark (what preceded it, was an "
                    "Authentication/SMC exchange triggered?).\n"
                    "2. Run the same pipeline on a control capture (baseline_comparison.py) before "
                    "relying on counts.\n"
                    "3. Attribution (hardware/operator) is a hypothesis unless independently corroborated."),
            spec_ref="3GPP TS 24.301 §5.4.4 (identification procedure); see individual findings",
        )
        f["source"] = "derived_from_findings"
        return [f]
