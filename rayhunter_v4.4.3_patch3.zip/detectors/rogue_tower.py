#!/usr/bin/env python3
"""
Rogue Tower Detector (v4.4.3)
=============================
Cross-references observed cells against OpenCelliD, the analyst's rogue/watch lists and
simple behavioural checks.

v4.4.3 fixes (see CHANGELOG_4.4.3.md):
  * Reads the config keys that actually exist (detection.rogue_tower.known_rogue_cids /
    known_rogue_enbs / watchlist_cids, detection.earfcn_anomaly.known_rogue_earfcns); the old
    top-level keys never matched, so list-based rules never fired.
  * Per-cell MCC/MNC for OpenCelliD lookups and EARFCN band checks (was session MNC, which
    produced false "not found"/"out of band" for Vodafone 505-03 cells).
  * PCI-only placeholders ("PCI-42") are never sent to OpenCelliD.
  * OpenCelliD errors other than "cell not found" (bad token, rate limit) are no longer
    cached/treated as "not found". Cache honours opencellid.cache_days. Lookup cap per run.
  * "Not in OpenCelliD" is weak evidence (crowdsourced) -> MEDIUM/SUSPECTED, not HIGH/PROBABLE.
  * Config-list membership is the analyst's conclusion, not new evidence -> MEDIUM/SUSPECTED
    unless detection.rogue_tower.list_match_as_confirmed: true.
  * Cells keyed by (MCC, MNC, cell id); every EARFCN/TAC seen is tracked, not just the first.
  * Robust RSRP parsing (no crash on "N/A"). Case refs come from config, not source.
"""
import json
import os
import time
from pathlib import Path
from typing import List, Dict, Optional

from .base import BaseDetector, make_finding

TELSTRA_EARFCN_RANGES = [(0, 599), (1200, 1949), (2750, 3449), (9210, 9659)]
VODAFONE_EARFCN_RANGES = [(0, 599), (1200, 1949), (3450, 3799), (9210, 9659)]
OPERATOR_EARFCNS = {
    "505-001": TELSTRA_EARFCN_RANGES,
    "505-003": VODAFONE_EARFCN_RANGES,
    "505-006": [(1200, 1949), (9210, 9659), (3450, 3799)],
}
CARRIERS = {"505-001": "Telstra AU", "505-003": "Vodafone AU", "505-006": "Optus AU"}


def norm_mnc(mnc) -> str:
    """'1' / '01' / '001' -> '001' (3-digit form used as dict key)."""
    s = str(mnc if mnc is not None else "").strip()
    return s.zfill(3) if s.isdigit() else s


def _to_float(v) -> Optional[float]:
    try:
        return float(str(v).replace("dBm", "").strip())
    except (ValueError, TypeError):
        return None


class RogueTowerDetector(BaseDetector):
    name = "RogueTowerDetector"
    description = "Cell DB cross-reference, analyst list matches and behavioural checks"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        net = cfg.get("network", {}) or {}
        det = cfg.get("detection", {}) or {}
        rt = det.get("rogue_tower", {}) or {}
        self.rt_cfg = rt
        self.mcc = str(net.get("mcc", "505"))
        self.mnc = norm_mnc(net.get("mnc", "001"))
        self.opencellid_cfg = cfg.get("opencellid", {}) or {}

        # list of CIDs (current config) + legacy dict {"505-001-<cid>": {notes}}
        self.rogue_cids = {str(c) for c in (rt.get("known_rogue_cids") or [])}
        self.legacy_cells = cfg.get("known_rogue_cells", {}) or {}
        self.rogue_enbs = {int(e) for e in (rt.get("known_rogue_enbs") or []) if str(e).isdigit()}
        self.watch_cids = {str(c) for c in (rt.get("watchlist_cids") or [])}
        earf = set((det.get("earfcn_anomaly", {}) or {}).get("known_rogue_earfcns", []) or [])
        earf |= set(cfg.get("known_rogue_earfcns", []) or [])
        self.known_rogue_earfcns = {int(e) for e in earf if str(e).isdigit()}
        self.band_table = dict(OPERATOR_EARFCNS)
        for k, v in (cfg.get("operator_earfcn_ranges", {}) or {}).items():
            self.band_table[k] = [tuple(r) for r in v]
        self.list_confirmed = bool(rt.get("list_match_as_confirmed", False))
        refs = (cfg.get("case_context", {}) or {}).get("references") or []
        self.case_ref = refs[0] if refs else None

        self._lookups_done = 0
        self._cache_ttl = float(self.opencellid_cfg.get("cache_days", 7)) * 86400
        self._cell_cache = self._load_cache()

    # ------------------------------------------------------------------ analyze
    def analyze(self, events: List[Dict]) -> List[Dict]:
        findings: List[Dict] = []
        cells = self._collect_cells(events)
        if not cells:
            return findings

        real = [c for c in cells if not c["placeholder"]]
        if len(real) >= 2:
            lines = []
            for c in real:
                lines.append(f"CID={c['cell_id']} TAC={'/'.join(sorted(map(str, c['tacs']))) or '?'} "
                             f"MCC={c['mcc']} MNC={c['mnc']} ({CARRIERS.get(c['mcc'] + '-' + c['mnc'], 'unknown carrier')}) "
                             f"EARFCN={'/'.join(map(str, sorted(c['earfcns']))) or '?'} "
                             f"observations={len(c['events'])}")
            findings.append(make_finding(
                detector=self.name, title=f"Cell Summary — {len(real)} Unique Cell ID(s) Observed",
                description=(f"{len(real)} unique cell IDs observed. This is an inventory, not a finding; "
                             "verify against operator/OpenCelliD data."),
                severity="INFO", confidence="CONFIRMED",
                technique="Cell ID inventory from SIB1 beacon data", evidence=lines, events=[],
                action="Enable OpenCelliD lookup in config.yaml to auto-check these cells."))

        for cell in cells:
            cid, evs = cell["cell_id"], cell["events"]
            op_key = f"{cell['mcc']}-{cell['mnc']}"
            op_name = CARRIERS.get(op_key, f"MCC={cell['mcc']} MNC={cell['mnc']}")

            # Rule 1: analyst list matches (membership is NOT independent evidence)
            if not cell["placeholder"]:
                enb = int(cid) >> 8 if str(cid).isdigit() else None
                listed = (str(cid) in self.rogue_cids or (enb in self.rogue_enbs if enb else False)
                          or f"{cell['mcc']}-{cell['mnc']}-{cid}" in self.legacy_cells
                          or f"{cell['mcc']}-{cell['mnc'].lstrip('0') or '0'}-{cid}" in self.legacy_cells)
                if listed:
                    sev, conf = ("CRITICAL", "CONFIRMED") if self.list_confirmed else ("MEDIUM", "SUSPECTED")
                    findings.append(make_finding(
                        detector=self.name,
                        title=f"Cell ID {cid} is on the analyst rogue list",
                        description=(f"Cell {cid} (eNB {enb}) is in your configured rogue list and was observed "
                                     f"{len(evs)} time(s). List membership records a prior conclusion; it is not "
                                     "new evidence. Weight comes from behavioural findings for this cell."),
                        severity=sev, confidence=conf,
                        technique="Analyst list match", evidence=self._fmt_cell(cell, evs), events=evs,
                        action="Review behavioural evidence (pre-security IMSI requests, redirects) for this CID.",
                        spec_ref=self.case_ref))
                elif str(cid) in self.watch_cids:
                    findings.append(make_finding(
                        detector=self.name, title=f"Watchlist cell {cid} observed",
                        description=f"Cell {cid} is on the watchlist ({len(evs)} observation(s)). Lead only.",
                        severity="INFO", confidence="SUSPECTED", technique="Watchlist match",
                        evidence=self._fmt_cell(cell, evs), events=evs))

            # Rule 2: OpenCelliD (skip PCI placeholders and non-numeric ids)
            if (not cell["placeholder"]) and str(cid).isdigit() and self.opencellid_cfg.get("enabled", False):
                tac = sorted(map(str, cell["tacs"]))[0] if cell["tacs"] else None
                res = self._lookup_opencellid(str(cid), cell["mcc"], cell["mnc"], tac)
                if res == "NOT_FOUND":
                    findings.append(make_finding(
                        detector=self.name, title=f"Cell ID {cid} not found in OpenCelliD",
                        description=(f"Cell {cid} (MCC={cell['mcc']} MNC={cell['mnc']} TAC={tac}) returned "
                                     "'cell not found'. OpenCelliD is crowdsourced and misses new, private "
                                     "and low-traffic cells, so absence is weak evidence on its own."),
                        severity="MEDIUM", confidence="SUSPECTED",
                        technique="Cell absent from public crowdsourced database",
                        evidence=self._fmt_cell(cell, evs), events=evs,
                        action=("Re-check manually at opencellid.org using the MNC shown above, and compare "
                                "with operator/ACMA site data before drawing conclusions."),
                        spec_ref="OpenCelliD: opencellid.org"))

            # Rule 3: known rogue EARFCN (any EARFCN seen on this cell)
            for e in sorted(cell["earfcns"] & self.known_rogue_earfcns):
                findings.append(make_finding(
                    detector=self.name, title=f"Listed rogue EARFCN {e} observed",
                    description=f"EARFCN {e} is on your rogue EARFCN list; seen on cell {cid} ({len(evs)} event(s)).",
                    severity="MEDIUM", confidence="SUSPECTED", technique="Analyst EARFCN list match",
                    evidence=self._fmt_cell(cell, evs), events=evs,
                    action="Confirm the EARFCN is outside the operator's licensed bands (TS 36.101) first."))

            # Rule 4: EARFCN outside this cell's own operator bands
            ranges = self.band_table.get(op_key)
            if ranges:
                for e in sorted(cell["earfcns"]):
                    if not any(lo <= e <= hi for lo, hi in ranges):
                        findings.append(make_finding(
                            detector=self.name, title=f"EARFCN {e} outside {op_name} configured bands",
                            description=(f"EARFCN {e} is outside the band table for {op_name} "
                                         f"({', '.join(f'{lo}-{hi}' for lo, hi in ranges)}). The table is a "
                                         "configured approximation; verify against the ACMA/operator register "
                                         "before treating this as out-of-band operation."),
                            severity="MEDIUM", confidence="SUSPECTED",
                            technique="EARFCN outside configured operator bands",
                            evidence=self._fmt_cell(cell, evs), events=evs,
                            action="Verify band allocation; extend `operator_earfcn_ranges` in config if legitimate.",
                            spec_ref="3GPP TS 36.101 Table 5.7.3-1"))

            # Rule 5: very strong signal
            rsrp = cell["rsrp"]
            if rsrp is not None and rsrp > -55:
                findings.append(make_finding(
                    detector=self.name, title=f"Strong signal (RSRP={rsrp:.1f} dBm)",
                    description=(f"Peak RSRP {rsrp:.1f} dBm. Values above about -55 dBm occur close to a "
                                 "legitimate site as well as near an overpowered transmitter; treat as a lead."),
                    severity="LOW", confidence="SUSPECTED", technique="High received power",
                    evidence=self._fmt_cell(cell, evs), events=evs,
                    action="Correlate with location/time and with identity-request events."))
        return findings

    # ------------------------------------------------------------------ helpers
    def _collect_cells(self, events: List[Dict]) -> List[Dict]:
        cell_map: Dict[tuple, Dict] = {}
        for ev in events:
            cid = ev.get("eci") or ev.get("cell_id") or ev.get("cid")
            pci = ev.get("pci")
            placeholder = False
            if cid is None and pci is not None:
                cid, placeholder = f"PCI-{pci}", True
            if cid is None and ev.get("earfcn") is None:
                continue
            mcc = str(ev.get("mcc") or self.mcc)
            mnc = norm_mnc(ev.get("mnc") or self.mnc)
            key = (mcc, mnc, str(cid if cid is not None else f"pci_{pci}@{ev.get('earfcn')}"))
            c = cell_map.setdefault(key, {"cell_id": cid, "earfcn": ev.get("earfcn"), "tac": ev.get("tac"),
                                          "mcc": mcc, "mnc": mnc, "rsrp": None, "events": [],
                                          "earfcns": set(), "tacs": set(), "placeholder": placeholder})
            c["events"].append(ev)
            try:
                if ev.get("earfcn") is not None:
                    c["earfcns"].add(int(ev["earfcn"]))
            except (TypeError, ValueError):
                pass
            if ev.get("tac") not in (None, ""):
                c["tacs"].add(str(ev["tac"]))
            r = _to_float(ev.get("rsrp"))
            if r is not None and (c["rsrp"] is None or r > c["rsrp"]):
                c["rsrp"] = r
        return list(cell_map.values())

    def _api_key(self) -> str:
        k = os.environ.get("OPENCELLID_API_KEY") or self.opencellid_cfg.get("api_key", "")
        return "" if str(k).startswith("REDACTED") else str(k)

    def _lookup_opencellid(self, cell_id: str, mcc: str, mnc: str, tac: Optional[str]):
        """Returns data dict (found), 'NOT_FOUND', or {} (unknown: error/skip). Only a real
        'cell not found' answer is ever cached as NOT_FOUND."""
        mnc_param = str(int(mnc)) if str(mnc).isdigit() else str(mnc)
        key = f"v2:{mcc}-{mnc_param}-{cell_id}-{tac}"
        hit = self._cell_cache.get(key)
        if isinstance(hit, dict) and "_ts" in hit and time.time() - hit["_ts"] < self._cache_ttl:
            return hit["data"]
        token = self._api_key()
        if not token:
            return {}
        cap = int(self.opencellid_cfg.get("max_lookups", 50))
        if self._lookups_done >= cap:
            return {}
        self._lookups_done += 1
        try:
            import requests
            resp = requests.get("https://opencellid.org/cell/get",
                                params={"token": token, "mcc": mcc, "mnc": mnc_param, "lac": tac or 0,
                                        "cellid": cell_id, "format": "json"},
                                timeout=self.opencellid_cfg.get("timeout_seconds", 5))
            data = resp.json()
        except Exception:
            return {}
        text = json.dumps(data).lower()
        if data.get("status") == "ok" or ("lat" in data and "lon" in data):
            out = data
        elif "not found" in text:
            out = "NOT_FOUND"
        else:
            return {}          # invalid token, rate limit, etc. -> unknown, don't cache
        self._cell_cache[key] = {"_ts": time.time(), "data": out}
        self._save_cache()
        return out

    def _load_cache(self) -> dict:
        try:
            with open(self.opencellid_cfg.get("cache_file", "cell_cache.json")) as f:
                d = json.load(f)
                return d if isinstance(d, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}

    def _save_cache(self):
        try:
            with open(self.opencellid_cfg.get("cache_file", "cell_cache.json"), "w") as f:
                json.dump(self._cell_cache, f)
        except Exception:
            pass

    def _op_name(self) -> str:
        return CARRIERS.get(f"{self.mcc}-{self.mnc}", f"MCC={self.mcc} MNC={self.mnc}")

    def _fmt_cell(self, cell: Dict, events: List[Dict]) -> List[str]:
        lines = [f"Cell ID:  {cell.get('cell_id', '?')}  (MCC {cell.get('mcc')} / MNC {cell.get('mnc')})",
                 f"EARFCN:   {'/'.join(map(str, sorted(cell.get('earfcns', [])))) or '?'}",
                 f"TAC/LAC:  {'/'.join(sorted(cell.get('tacs', []))) or '?'}",
                 f"Peak RSRP: {cell.get('rsrp', '?')} dBm",
                 f"Events:   {len(events)} observation(s)"]
        if events:
            lines.append(f"First seen: {events[0].get('timestamp', '?')} in {events[0].get('source_file', '?')}")
        return lines
