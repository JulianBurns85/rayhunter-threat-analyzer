## [4.4.3] - 2026-10-21
### Fixed
- `make_finding()` now accepts `data_source` and extra fields (synthesiser previously raised TypeError).
- Synthesiser/rhythm read `msg_type` OR `message_type`; release/cell counts were silently 0.
- Synthesiser: all content derived from findings; no hardcoded hardware/address/operator claims;
  zero-count techniques omitted; severity follows evidence; "days" = active days (>= N events).
- Rhythm: DST-aware Melbourne time (was fixed AEST); no timezone overwrite; slot-based binomial
  tests; severity capped at MEDIUM; control comparison hook (`analysis.rhythm_control`).
- `forensic_time`: us/ns scales handled; sparse-day filter; untrusted (mtime/boot-relative) timestamps excluded.
- `baseline_comparison.py` v2: field-based NAS extraction, pcap+pcapng, rates per capture-hour,
  identical checks on both sides, exact binomial test. `baseline_rrc.py` removed (use `--mode inventory`).
- requirements: `tzdata` on Windows. Tests added under tests/.
- `rogue_tower.py`: reads real config keys (known_rogue_cids/enbs, watchlist, earfcn_anomaly list);
  per-cell MNC for OpenCelliD + band checks; PCI placeholders never looked up; only a genuine
  "not found" is cached/reported; cache TTL + lookup cap; absence-from-OpenCelliD and list matches
  downgraded (weak/circular evidence); multi-EARFCN/TAC tracking; safe RSRP parsing; no case refs in source.
- `tests/test_synthetic.py`: pytest-collectable, cwd-independent, tmp output, no network.
